GOLDEN AUTUMN HERITAGE — 32 CUTOUT PREVIEWS

These are prototype cutouts derived from ONE 1536×1024 generated CONTACT SHEET, not 32 independently rendered high-resolution outputs.
All 32 files have been cropped and background-estimated with transparent alpha (sky is opaque). Generated checkerboard was baked into the contact sheet, so cutout transparency is heuristic and may show halos or missing pale details.
Please DO NOT use these as final production-quality art for a premium wedding website: individual images are too small, and some original generator labels are incorrectly numbered. Filenames in this ZIP follow the 32 original prompts.

For the final site, regenerate the 32 prompts as individually rendered high-resolution PNGs, lock the same visual style/lighting, verify true alpha, and optimize with WebP/AVIF.
